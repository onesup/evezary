window.onload = function() {
	var width = $(document).width();
	var height = $(".imageslider").height() * ($(document).width() / $(".imageslider").width());
	
	var imageslider_current = 0;
	var imageslider_last_index = $(".imageslider .image").length - 1;
	
	$(".imageslider").width(width);
	$(".imageslider").height(height);
	$(".imageslider .images").width(width);
	$(".imageslider .images").height(height);
	
	var total_width = 0;
	$(".imageslider .image").each(function(index, item) {
		$(this).css("left", total_width);
		total_width += width;
	
		$(".imageslider .navigator").append(
			$(this).clone().find("img").addClass("thumbnail").click(function() {
				imageslider_current = index;
				imageslider_slideTo(index);
			})
		);
	});
	
	$(".imageslider .image img").each(function() {
		$(this).width(width);
		$(this).height(height);
	});
	
	$(".imageslider .imageslider_left").click(function() {
		imageslider_current--;
		imageslider_slideTo(imageslider_current);
	});
	
	$(".imageslider .imageslider_right").click(function() {
		imageslider_current++;
		imageslider_slideTo(imageslider_current);
	});
	
	imageslider_updateLayout();
	
	function imageslider_slideTo(index) {
		imageslider_current = index;
		
		imageslider_updateLayout();
		
		var left = $(".imageslider .image").eq(index).css("left");
		$(".imageslider .images").animate({
			scrollLeft: left
		}, 400);
	}
	
	function imageslider_updateLayout() {
		if(imageslider_current == 0) {
			$(".imageslider .imageslider_left").hide();
			$(".imageslider .imageslider_right").show();
		}
		else if(imageslider_current == imageslider_last_index) {
			$(".imageslider .imageslider_left").show();
			$(".imageslider .imageslider_right").hide();
		}
		else {
			$(".imageslider .imageslider_left").show();
			$(".imageslider .imageslider_right").show();
		}
		
		$(".imageslider .navigator .thumbnail").each(function(index) {
			if(index == imageslider_current) {
				$(this).addClass("current");
			}
			else {
				$(this).removeClass("current");
			}
		});
	}
};